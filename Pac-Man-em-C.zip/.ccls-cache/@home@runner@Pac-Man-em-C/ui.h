#ifndef _UI_H   // se não tiver definido 
#define _UI_H

#include "mapa.h"

void imprimeparte(char desenho[4][7], int parte);
void imprimemapa(MAPA *m);






#endif